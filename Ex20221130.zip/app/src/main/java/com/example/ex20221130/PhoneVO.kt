package com.example.ex20221130

class PhoneVO(val imgId: Int, val name: String, val tel: String) {
    // img의 Id값
    // name
    // tel

}